// Self-contained CampaignsPage component without external dependencies
import React, { useState, useEffect } from 'react';
import { 
  Plus, Play, Pause, Trash2, Edit, BarChart, Clock, 
  CheckCircle, XCircle, RefreshCw, Activity, Target,
  FileText, TrendingUp, AlertCircle
} from 'lucide-react';

const CampaignsPage = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [notification, setNotification] = useState(null);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    completed: 0,
    failed: 0,
    totalProcessed: 0,
    avgSuccessRate: 0
  });

  // Show notification (replacement for toast)
  const showNotification = (message, type = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  // API call simulation (replace with your actual API logic)
  const apiCall = async (endpoint, options = {}) => {
    const token = localStorage.getItem('access_token');
    const baseURL = 'http://localhost:8000/api';
    
    try {
      const response = await fetch(`${baseURL}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          ...options.headers
        }
      });

      if (!response.ok) {
        if (response.status === 401) {
          window.location.href = '/';
          throw new Error('Authentication required');
        }
        throw new Error(`API Error: ${response.status}`);
      }

      return await response.json();
    } catch (err) {
      console.error('API Error:', err);
      throw err;
    }
  };

  // Fetch campaigns from backend
  const fetchCampaigns = async () => {
    try {
      setError(null);
      if (!loading) setRefreshing(true);
      
      console.log('[CAMPAIGNS] Fetching campaigns...');
      
      const data = await apiCall('/campaigns');
      
      // Handle different response formats from backend
      let campaignsData = [];
      if (Array.isArray(data)) {
        campaignsData = data;
      } else if (data?.campaigns) {
        campaignsData = data.campaigns;
      } else if (data?.items) {
        campaignsData = data.items;
      }

      // Normalize campaign data structure
      const normalizedCampaigns = campaignsData.map(campaign => ({
        id: campaign.id || campaign._id,
        name: campaign.name || `Campaign #${campaign.id}`,
        fileName: campaign.file_name || campaign.fileName || 'unknown.csv',
        status: campaign.status?.toLowerCase() || 'draft',
        totalWebsites: campaign.total_websites || campaign.totalWebsites || 0,
        processed: campaign.processed || 0,
        successful: campaign.successful || 0,
        failed: campaign.failed || 0,
        emailFallback: campaign.email_fallback || campaign.emailFallback || 0,
        noForm: campaign.no_form || campaign.noForm || 0,
        startTime: campaign.start_time || campaign.startTime || campaign.created_at,
        endTime: campaign.end_time || campaign.endTime,
        successRate: campaign.success_rate || calculateSuccessRate(campaign),
        createdAt: campaign.created_at || campaign.createdAt,
        updatedAt: campaign.updated_at || campaign.updatedAt
      }));

      setCampaigns(normalizedCampaigns);
      
      // Calculate statistics
      const activeCount = normalizedCampaigns.filter(c => 
        c.status === 'running' || c.status === 'active'
      ).length;
      
      const completedCount = normalizedCampaigns.filter(c => 
        c.status === 'completed'
      ).length;
      
      const failedCount = normalizedCampaigns.filter(c => 
        c.status === 'failed'
      ).length;
      
      const totalProcessed = normalizedCampaigns.reduce((sum, c) => 
        sum + (c.processed || 0), 0
      );
      
      const avgSuccessRate = normalizedCampaigns.length > 0
        ? normalizedCampaigns.reduce((sum, c) => sum + (c.successRate || 0), 0) / normalizedCampaigns.length
        : 0;

      setStats({
        total: normalizedCampaigns.length,
        active: activeCount,
        completed: completedCount,
        failed: failedCount,
        totalProcessed,
        avgSuccessRate
      });

      console.log('[CAMPAIGNS] Loaded', normalizedCampaigns.length, 'campaigns');
      
    } catch (err) {
      console.error('[CAMPAIGNS] Error:', err);
      
      let errorMessage = 'Failed to load campaigns';
      if (!navigator.onLine) {
        errorMessage = 'No internet connection';
      }
      
      setError(errorMessage);
      showNotification(errorMessage, 'error');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Calculate success rate
  const calculateSuccessRate = (campaign) => {
    const total = campaign.processed || 0;
    const successful = campaign.successful || 0;
    return total > 0 ? Math.round((successful / total) * 100) : 0;
  };

  // Initial load
  useEffect(() => {
    fetchCampaigns();
  }, []);

  // Auto-refresh for active campaigns
  useEffect(() => {
    if (stats.active > 0) {
      const interval = setInterval(() => {
        if (document.visibilityState === 'visible') {
          fetchCampaigns();
        }
      }, 5000); // Refresh every 5 seconds when there are active campaigns
      
      return () => clearInterval(interval);
    }
  }, [stats.active]);

  // Campaign actions
  const handleStartCampaign = async (campaignId) => {
    try {
      await apiCall(`/campaigns/${campaignId}/start`, { method: 'POST' });
      showNotification('Campaign started successfully', 'success');
      fetchCampaigns();
    } catch (err) {
      showNotification('Failed to start campaign', 'error');
    }
  };

  const handleStopCampaign = async (campaignId) => {
    try {
      await apiCall(`/campaigns/${campaignId}/stop`, { method: 'POST' });
      showNotification('Campaign stopped successfully', 'success');
      fetchCampaigns();
    } catch (err) {
      showNotification('Failed to stop campaign', 'error');
    }
  };

  const handleDeleteCampaign = async (campaignId) => {
    if (!window.confirm('Are you sure you want to delete this campaign?')) return;
    
    try {
      await apiCall(`/campaigns/${campaignId}`, { method: 'DELETE' });
      showNotification('Campaign deleted successfully', 'success');
      fetchCampaigns();
    } catch (err) {
      showNotification('Failed to delete campaign', 'error');
    }
  };

  const handleCreateCampaign = () => {
    window.location.href = '/form-submitter';
  };

  const handleViewCampaign = (campaignId) => {
    window.location.href = `/campaigns/${campaignId}`;
  };

  // Get status color and label
  const getStatusDisplay = (status) => {
    const statusMap = {
      'draft': { color: 'bg-gray-100 text-gray-700', label: 'Draft' },
      'ready': { color: 'bg-blue-100 text-blue-700', label: 'Ready' },
      'running': { color: 'bg-green-100 text-green-700', label: 'Running' },
      'active': { color: 'bg-green-100 text-green-700', label: 'Active' },
      'paused': { color: 'bg-yellow-100 text-yellow-700', label: 'Paused' },
      'completed': { color: 'bg-blue-100 text-blue-700', label: 'Completed' },
      'failed': { color: 'bg-red-100 text-red-700', label: 'Failed' },
      'stopped': { color: 'bg-gray-100 text-gray-700', label: 'Stopped' }
    };
    
    return statusMap[status?.toLowerCase()] || statusMap['draft'];
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Format duration
  const formatDuration = (startTime, endTime) => {
    if (!startTime) return 'N/A';
    const start = new Date(startTime);
    const end = endTime ? new Date(endTime) : new Date();
    const diff = Math.floor((end - start) / 1000);
    
    const hours = Math.floor(diff / 3600);
    const minutes = Math.floor((diff % 3600) / 60);
    
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  if (loading && campaigns.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading campaigns...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Notification */}
      {notification && (
        <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg ${
          notification.type === 'success' ? 'bg-green-500 text-white' :
          notification.type === 'error' ? 'bg-red-500 text-white' :
          'bg-blue-500 text-white'
        }`}>
          {notification.message}
        </div>
      )}

      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Campaigns</h1>
              <p className="text-gray-600">Manage your outreach campaigns</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => fetchCampaigns()}
                disabled={refreshing}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </button>
              <button
                onClick={handleCreateCampaign}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <Plus className="w-5 h-5" />
                New Campaign
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <BarChart className="w-8 h-8 text-indigo-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active</p>
                <p className="text-2xl font-bold text-green-600">{stats.active}</p>
              </div>
              <Activity className="w-8 h-8 text-green-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-blue-600">{stats.completed}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Failed</p>
                <p className="text-2xl font-bold text-red-600">{stats.failed}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Processed</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalProcessed.toLocaleString()}</p>
              </div>
              <FileText className="w-8 h-8 text-gray-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold text-purple-600">{stats.avgSuccessRate.toFixed(0)}%</p>
              </div>
              <Target className="w-8 h-8 text-purple-600" />
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <span className="text-red-800">{error}</span>
            </div>
          </div>
        )}

        {/* Campaigns Table */}
        {campaigns.length > 0 ? (
          <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Campaign
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Progress
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Success Rate
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Duration
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Created
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {campaigns.map((campaign) => {
                    const statusDisplay = getStatusDisplay(campaign.status);
                    const progress = campaign.totalWebsites > 0 
                      ? Math.round((campaign.processed / campaign.totalWebsites) * 100)
                      : 0;
                    
                    return (
                      <tr 
                        key={campaign.id} 
                        className="hover:bg-gray-50 cursor-pointer"
                        onClick={() => handleViewCampaign(campaign.id)}
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {campaign.name}
                            </div>
                            <div className="text-xs text-gray-500">
                              {campaign.fileName} • {campaign.totalWebsites} URLs
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusDisplay.color}`}>
                            {statusDisplay.label}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-1">
                              <div className="text-sm text-gray-900">
                                {campaign.processed} / {campaign.totalWebsites}
                              </div>
                              <div className="mt-1 w-full bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-indigo-600 h-2 rounded-full transition-all"
                                  style={{ width: `${progress}%` }}
                                />
                              </div>
                            </div>
                            <span className="ml-2 text-sm text-gray-600">{progress}%</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <span className="text-sm font-medium text-gray-900">
                              {campaign.successRate}%
                            </span>
                            {campaign.successRate >= 90 && (
                              <TrendingUp className="w-4 h-4 text-green-500 ml-1" />
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDuration(campaign.startTime, campaign.endTime)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(campaign.createdAt)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex items-center justify-end gap-2">
                            {(campaign.status === 'draft' || campaign.status === 'ready' || campaign.status === 'stopped') && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleStartCampaign(campaign.id);
                                }}
                                className="text-green-600 hover:text-green-900"
                                title="Start Campaign"
                              >
                                <Play className="w-4 h-4" />
                              </button>
                            )}
                            {(campaign.status === 'running' || campaign.status === 'active') && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleStopCampaign(campaign.id);
                                }}
                                className="text-yellow-600 hover:text-yellow-900"
                                title="Stop Campaign"
                              >
                                <Pause className="w-4 h-4" />
                              </button>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteCampaign(campaign.id);
                              }}
                              className="text-red-600 hover:text-red-900"
                              title="Delete Campaign"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          !loading && !error && (
            <div className="bg-white rounded-lg shadow-sm border p-12">
              <div className="text-center">
                <BarChart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No campaigns yet</h3>
                <p className="text-gray-500 mb-4">Get started by creating your first campaign</p>
                <button
                  onClick={handleCreateCampaign}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  Create First Campaign
                </button>
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
};

export default CampaignsPage;