// UserDashboard.jsx - CORRECTED END TO END
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Play, CheckCircle, Clock, Mail, Globe, AlertCircle, Upload, 
  FileText, TrendingUp, BarChart3, Activity, Target, RefreshCw, 
  Loader, Settings, LogOut, User, Eye, Plus
} from 'lucide-react';
import api from '../services/api'; // Use existing API service
import toast from 'react-hot-toast';

const UserDashboard = () => {
  const navigate = useNavigate();

  // State management
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  
  // Data from database
  const [campaigns, setCampaigns] = useState([]);
  const [userAnalytics, setUserAnalytics] = useState(null);
  const [dailyStats, setDailyStats] = useState([]);
  const [recentSubmissions, setRecentSubmissions] = useState([]);
  const [userProfile, setUserProfile] = useState(null);

  // Fetch dashboard data
  const fetchDashboardData = async () => {
    try {
      setError(null);
      console.log('[DASHBOARD] Fetching data...');
      
      // Fetch data in parallel - using existing API endpoints
      const [
        campaignsResponse,
        analyticsResponse,
        dailyStatsResponse,
        submissionsResponse,
        profileResponse
      ] = await Promise.allSettled([
        api.get('/campaigns?page=1&per_page=10'),
        api.get('/analytics/user'),
        api.get('/analytics/daily-stats?days=30'),
        api.get('/submissions?page=1&per_page=10'),
        api.get('/users/profile')
      ]);

      // Process campaigns
      if (campaignsResponse.status === 'fulfilled') {
        const campaignsData = campaignsResponse.value.data;
        setCampaigns(campaignsData.campaigns || campaignsData || []);
      }

      // Process analytics
      if (analyticsResponse.status === 'fulfilled') {
        setUserAnalytics(analyticsResponse.value.data);
      }

      // Process daily stats
      if (dailyStatsResponse.status === 'fulfilled') {
        setDailyStats(dailyStatsResponse.value.data || []);
      }

      // Process submissions
      if (submissionsResponse.status === 'fulfilled') {
        const submissionsData = submissionsResponse.value.data;
        setRecentSubmissions(submissionsData.submissions || submissionsData || []);
      }

      // Process profile
      if (profileResponse.status === 'fulfilled') {
        setUserProfile(profileResponse.value.data);
      }

      console.log('[DASHBOARD] Data loaded successfully');

    } catch (err) {
      console.error('[DASHBOARD] Error fetching data:', err);
      setError(err.message);
      
      if (err.response?.status === 401) {
        toast.error('Session expired. Please login again.');
        navigate('/');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Auto refresh for running campaigns
  useEffect(() => {
    const hasRunningCampaign = campaigns.some(c => 
      c.status === 'active' || c.status === 'running'
    );

    if (hasRunningCampaign) {
      const interval = setInterval(() => {
        if (document.visibilityState === 'visible') {
          fetchDashboardData();
        }
      }, 10000); // Refresh every 10 seconds

      return () => clearInterval(interval);
    }
  }, [campaigns]);

  // Action handlers
  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardData();
  };

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    toast.success('Logged out successfully');
    navigate('/');
  };

  // FIXED: Use correct navigation routes
  const handleStartNewCampaign = () => {
    console.log('[DASHBOARD] Navigating to form submitter...');
    navigate('/form-submitter'); // This route exists
  };

  const handleViewCampaigns = () => {
    navigate('/campaigns'); // This route exists
  };

  const handleViewCampaign = (campaignId) => {
    navigate(`/campaigns/${campaignId}`);
  };

  // Calculate statistics
  const calculateStats = () => {
    const stats = userAnalytics?.stats || {};
    return {
      totalCampaigns: userAnalytics?.total_campaigns || campaigns.length,
      totalSubmissions: stats.total_submissions || 0,
      successful: stats.successful_submissions || 0,
      failed: stats.failed_submissions || 0,
      pending: stats.pending_submissions || 0,
      successRate: stats.success_rate || 0
    };
  };

  const stats = calculateStats();
  const activeCampaign = campaigns.find(c => c.status === 'active' || c.status === 'running');

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error && !campaigns.length && !userAnalytics) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-sm border max-w-md">
          <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 text-center mb-2">
            Connection Error
          </h2>
          <p className="text-gray-600 text-center mb-4">{error}</p>
          <div className="space-y-2">
            <button
              onClick={fetchDashboardData}
              className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Try Again
            </button>
            <button
              onClick={handleLogout}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
              {userProfile && (
                <span className="text-sm text-gray-600">
                  Welcome, {userProfile.first_name || userProfile.email || 'User'}
                </span>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={handleRefresh}
                disabled={refreshing}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                title="Refresh"
              >
                <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
              </button>
              
              <button
                onClick={handleLogout}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        
        {/* Campaign Status Card */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Campaign Status</h2>
            {activeCampaign ? (
              <span className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
                <Play className="w-4 h-4 inline mr-1" />
                Running
              </span>
            ) : (
              <span className="px-3 py-1 bg-gray-100 text-gray-800 text-sm font-medium rounded-full">
                Idle
              </span>
            )}
          </div>
          
          {activeCampaign ? (
            // Active campaign display
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-medium">{activeCampaign.name}</h3>
                  <p className="text-sm text-gray-500">
                    ID: {activeCampaign.id?.slice(0, 8)}...
                  </p>
                </div>
                <button
                  onClick={() => handleViewCampaign(activeCampaign.id)}
                  className="px-3 py-1.5 text-sm bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  <Eye className="w-4 h-4 inline mr-1" />
                  View Details
                </button>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span>
                    {(activeCampaign.submitted_count || 0) + (activeCampaign.failed_count || 0)} of {activeCampaign.total_urls || 0}
                  </span>
                  <span>
                    {activeCampaign.total_urls ? 
                      Math.round(((activeCampaign.submitted_count || 0) + (activeCampaign.failed_count || 0)) / activeCampaign.total_urls * 100) 
                      : 0}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-indigo-500 to-indigo-600 h-3 rounded-full transition-all"
                    style={{ 
                      width: `${activeCampaign.total_urls ? 
                        ((activeCampaign.submitted_count || 0) + (activeCampaign.failed_count || 0)) / activeCampaign.total_urls * 100 
                        : 0}%` 
                    }}
                  />
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold">{activeCampaign.total_urls || 0}</p>
                  <p className="text-xs text-gray-500">Total</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-green-600">{activeCampaign.submitted_count || 0}</p>
                  <p className="text-xs text-gray-500">Success</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-red-600">{activeCampaign.failed_count || 0}</p>
                  <p className="text-xs text-gray-500">Failed</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-yellow-600">
                    {(activeCampaign.total_urls || 0) - (activeCampaign.submitted_count || 0) - (activeCampaign.failed_count || 0)}
                  </p>
                  <p className="text-xs text-gray-500">Pending</p>
                </div>
              </div>
            </div>
          ) : (
            // Idle state
            <div>
              {campaigns.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <p className="text-xs text-gray-500 mb-2">LAST CAMPAIGN</p>
                  <p className="font-medium">{campaigns[0].name}</p>
                  <div className="grid grid-cols-3 gap-4 mt-3 text-center">
                    <div>
                      <p className="text-xl font-bold">{campaigns[0].total_urls || 0}</p>
                      <p className="text-xs text-gray-500">URLs</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-green-600">{campaigns[0].submitted_count || 0}</p>
                      <p className="text-xs text-gray-500">Submitted</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold">
                        {campaigns[0].created_at ? new Date(campaigns[0].created_at).toLocaleDateString() : 'N/A'}
                      </p>
                      <p className="text-xs text-gray-500">Date</p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex space-x-3">
                <button
                  onClick={handleStartNewCampaign}
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Start New Campaign
                </button>
                {campaigns.length > 0 && (
                  <button
                    onClick={handleViewCampaigns}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    View All Campaigns
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">Total Campaigns</p>
              <FileText className="w-5 h-5 text-indigo-600" />
            </div>
            <p className="text-3xl font-bold text-indigo-600">{stats.totalCampaigns}</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">Total Submissions</p>
              <Target className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-blue-600">{stats.totalSubmissions}</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">Successful</p>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-green-600">{stats.successful}</p>
            <p className="text-xs text-gray-500 mt-1">{stats.successRate}% success rate</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-500">Failed</p>
              <AlertCircle className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-3xl font-bold text-red-600">{stats.failed}</p>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Recent Activity</h3>
            <Activity className="w-5 h-5 text-gray-400" />
          </div>
          
          {recentSubmissions.length > 0 ? (
            <div className="space-y-3">
              {recentSubmissions.slice(0, 5).map((submission) => (
                <div key={submission.id} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                  {submission.status === 'success' ? (
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  ) : submission.status === 'failed' ? (
                    <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                  ) : (
                    <Clock className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                  )}
                  <div className="flex-1">
                    <p className="text-sm font-medium">{submission.url || 'Unknown URL'}</p>
                    <p className="text-xs text-gray-500">
                      {submission.status} • {submission.created_at ? new Date(submission.created_at).toLocaleString() : 'Recently'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No recent activity</p>
              <p className="text-sm text-gray-400 mt-1">Start a campaign to see submissions here</p>
            </div>
          )}
        </div>

        {/* Campaigns List */}
        {campaigns.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Recent Campaigns</h3>
              <button
                onClick={handleViewCampaigns}
                className="text-sm text-indigo-600 hover:text-indigo-800"
              >
                View All
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="text-left text-sm text-gray-500 border-b">
                  <tr>
                    <th className="pb-2">Name</th>
                    <th className="pb-2">Status</th>
                    <th className="pb-2">URLs</th>
                    <th className="pb-2">Success</th>
                    <th className="pb-2">Created</th>
                    <th className="pb-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {campaigns.slice(0, 5).map((campaign) => (
                    <tr key={campaign.id} className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-3 font-medium">{campaign.name || `Campaign ${campaign.id?.slice(0, 8)}...`}</td>
                      <td className="py-3">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          campaign.status === 'completed' ? 'bg-green-100 text-green-700' :
                          campaign.status === 'active' || campaign.status === 'running' ? 'bg-blue-100 text-blue-700' :
                          campaign.status === 'failed' ? 'bg-red-100 text-red-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {campaign.status || 'draft'}
                        </span>
                      </td>
                      <td className="py-3">{campaign.total_urls || 0}</td>
                      <td className="py-3">{campaign.submitted_count || 0}</td>
                      <td className="py-3 text-sm text-gray-500">
                        {campaign.created_at ? new Date(campaign.created_at).toLocaleDateString() : 'N/A'}
                      </td>
                      <td className="py-3">
                        <button
                          onClick={() => handleViewCampaign(campaign.id)}
                          className="text-sm text-indigo-600 hover:text-indigo-800"
                        >
                          <Eye className="w-4 h-4 inline mr-1" />
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default UserDashboard;